import { combineReducers } from "redux";

import todoreducer from "./todoreducer";

const rootReducer = combineReducers({
  todoreducer,
});
export default rootReducer;
